rm -rf client/node_modules client/.deno client/.vite client/.cache \
       server/node_modules server/.deno
