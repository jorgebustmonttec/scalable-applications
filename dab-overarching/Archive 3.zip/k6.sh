docker compose run --rm --entrypoint=k6 k6-tests run /tests/hello-k6.js
